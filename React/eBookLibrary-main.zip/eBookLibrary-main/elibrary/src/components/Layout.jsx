import React from 'react';
//import Menu from './Menu';
//import '../styles.css';
import '../App.css';


const Layout = () => (
    <div>
        <div className='jumbotron mt-5'>
            <h2>Home Page</h2>
            <p className='lead'>MERN E-Library App</p>
        </div>
        <div className='container-fluid'>xyz</div>
    </div>
);

export default Layout;